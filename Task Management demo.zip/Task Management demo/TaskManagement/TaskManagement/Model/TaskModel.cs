﻿using System.ComponentModel.DataAnnotations;

namespace TaskManagement.Model
{
    public class TaskModel
    {
        public int ID { get; set; }

        [Display(Name = "Name")]
        public string TaskName { get; set; } = string.Empty;

        [Display(Name = "Description")]
        public string TaskDescription { get; set; } = string.Empty;

        public int TaskStatusId { get; set; }

        [Display(Name = "Status")]
        public string StatusName { get; set; }
    }
}
