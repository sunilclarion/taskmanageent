﻿using Microsoft.AspNetCore.Mvc;
using TaskManagement.Repository;

namespace TaskManagement.Controllers
{
    public class TaskController : Controller
    {
        private readonly ITaskRepository _taskRepository;

        public TaskController(ITaskRepository taskRepository)
        {
            _taskRepository = taskRepository;
        }

        [HttpGet]
        public async Task<ActionResult> Index()
        {
            var list = await _taskRepository.GetTaskList();
            return View(list);
        }
    }
}
