﻿using Dapper;
using TaskManagement.Data;
using TaskManagement.Model;

namespace TaskManagement.Repository
{
    public class TaskRepository : ITaskRepository
    {
        private readonly DapperContext context;

        public TaskRepository()
        {
            this.context = new DapperContext();
        }

        public async Task<List<TaskModel>> GetTaskList()
        {
            //This inline query is for demo please use store procedure
            var query = "SELECT * FROM TaskList";

            using (var connection = context.CreateConnection())
            {
                var companies = await connection.QueryAsync<TaskModel>(query);
                return companies.ToList();
            }
        }

        public async Task<TaskModel> GetTask(int id)
        {
            return new TaskModel();
        }

       
    }
}
