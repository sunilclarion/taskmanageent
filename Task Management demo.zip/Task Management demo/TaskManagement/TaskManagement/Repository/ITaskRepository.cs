﻿using TaskManagement.Model;

namespace TaskManagement.Repository
{
    public interface ITaskRepository
    {
        Task<List<TaskModel>> GetTaskList();
        Task<TaskModel> GetTask(int id);
        
    }
}
